﻿using System.Web.UI;

namespace SE256_Lab1_CSouthey.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}